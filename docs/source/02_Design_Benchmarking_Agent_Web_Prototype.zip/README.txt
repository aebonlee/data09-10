# Design Benchmarking Agent — Web Dashboard Prototype

This is a UI/UX prototype based on the Design Benchmarking Agent planning document.
The prototype contains 13 user-facing stages:

1 Scope Setup
2 Target Sources
3 Collection
4 Normalize & QA
5 Multimodal Analysis
6 Knowledge Layer
7 Benchmark Retrieval
8 Insight Agent
9 Web Dashboard
10 Report & Decision
11 Designer Validation
12 Prompt / Schema Tuning
13 Scheduled Update

Open `index.html` in a browser. The sidebar navigates between pages.
This is a prototype using representative/generated UI data rather than live competitor feeds.
